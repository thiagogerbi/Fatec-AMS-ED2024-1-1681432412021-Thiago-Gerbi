#ifndef RESERVA_H
#define RESERVA_H

// Definição da estrutura de dados para uma reserva
typedef struct Reserva {
    char nome_cliente[50];
    int num_pessoas;
    int dia; // 1 a 31
    int mes; // 1 a 12
    int ano; // 2024, por exemplo
    int hora; // 0 a 23
    struct Reserva* prox;
} Reserva;

// Protótipos de função
Reserva* criar_reserva(char* nome_cliente, int num_pessoas, int dia, int mes, int ano, int hora);
void adicionar_reserva(Reserva* nova_reserva);
void remover_reserva(char* nome_cliente, int dia, int mes, int ano, int hora);
int verificar_disponibilidade(int dia, int mes, int ano, int hora);
void gerar_relatorio_ocupacao(int dia, int mes, int ano);

#endif /* RESERVA_H */
