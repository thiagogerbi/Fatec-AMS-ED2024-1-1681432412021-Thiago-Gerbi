#ifndef RESERVA_H
#define RESERVA_H

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PESSOAS 20
#define NUM_DIAS 1000

typedef struct {
  char nome[50];
  char sobrenome[50];
  int num_pessoas;
  char data[20];
  char horario[10];
} Reserva;

typedef struct No {
  Reserva reserva;
  struct No *prox;
} No;

No *criarNo(Reserva reserva);
void adicionarReserva(No **lista, Reserva reserva);
void removerReserva(No **lista, char nome[], char sobrenome[]);
void exibirReservas(No *lista);
void consultarReservas(No *lista, char data[], char horario[]);
void relatorioOcupacao(No *lista, char inicio_data[], char fim_data[]);
int validarData(char data[]);
int validarHorario(char horario[]);

#endif /* RESERVA_H */
