#include "reserva.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    No *lista_reservas = NULL;
    Reserva nova_reserva;

    int opcao;
    do {
        printf("\nMenu:\n");
        printf("1. Adicionar Reserva\n");
        printf("2. Remover Reserva\n");
        printf("3. Exibir Reservas\n");
        printf("4. Consultar Reservas em Horário Específico\n");
        printf("5. Gerar Relatório de Ocupação\n");
        printf("6. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                printf("\nInsira os dados da reserva:\n");
                printf("Nome do cliente: ");
                scanf("%s", nova_reserva.nome);
                printf("Sobrenome do cliente: ");
                scanf("%s", nova_reserva.sobrenome);
                printf("Número de pessoas: ");
                scanf("%d", &nova_reserva.num_pessoas);
                while (nova_reserva.num_pessoas <= 0 || nova_reserva.num_pessoas > MAX_PESSOAS) {
                    printf("Número de pessoas inválido. Insira novamente (entre 1 e %d): ", MAX_PESSOAS);
                    scanf("%d", &nova_reserva.num_pessoas);
                }
                printf("Data (DD-MM-AAAA): ");
                scanf("%s", nova_reserva.data);
                while (!validarData(nova_reserva.data)) {
                    printf("Data inválida. Insira novamente (formato: DD-MM-AAAA): ");
                    scanf("%s", nova_reserva.data);
                }
                printf("Horário (HH:MM): ");
                scanf("%s", nova_reserva.horario);
                while (!validarHorario(nova_reserva.horario)) {
                    printf("Horário inválido. Insira novamente (formato: HH:MM): ");
                    scanf("%s", nova_reserva.horario);
                }
                adicionarReserva(&lista_reservas, nova_reserva);
                break;
            case 2:
                printf("\nInsira o nome e sobrenome do cliente para remover a reserva: ");
                char nome_remover[50];
                char sobrenome_remover[50];
                scanf("%s", nome_remover);
                scanf("%s", sobrenome_remover);
                removerReserva(&lista_reservas, nome_remover, sobrenome_remover);
                break;
            case 3:
                exibirReservas(lista_reservas);
                break;
            case 4:
                printf("\nInsira a data (DD-MM-AAAA): ");
                char data_consulta[20];
                scanf("%s", data_consulta);
                while (!validarData(data_consulta)) {
                    printf("Data inválida. Insira novamente (formato: DD-MM-AAAA): ");
                    scanf("%s", data_consulta);
                }
                printf("Insira o horário (HH:MM): ");
                char horario_consulta[10];
                scanf("%s", horario_consulta);
                while (!validarHorario(horario_consulta)) {
                    printf("Horário inválido. Insira novamente (formato: HH:MM): ");
                    scanf("%s", horario_consulta);
                }
                consultarReservas(lista_reservas, data_consulta, horario_consulta);
                break;
            case 5:
                printf("\nIntervalo de tempo para o relatório:\n");
                printf("Data de início (DD-MM-AAAA): ");
                char inicio_data[20];
                scanf("%s", inicio_data);
                while (!validarData(inicio_data)) {
                    printf("Data inválida. Insira novamente (formato: DD-MM-AAAA): ");
                    scanf("%s", inicio_data);
                }
                printf("Data de fim (DD-MM-AAAA): ");
                char fim_data[20];
                scanf("%s", fim_data);
                while (!validarData(fim_data)) {
                    printf("Data inválida. Insira novamente (formato: DD-MM-AAAA): ");
                    scanf("%s", fim_data);
                }
                relatorioOcupacao(lista_reservas, inicio_data, fim_data);
                break;
            case 6:
                printf("Saindo...\n");
                break;
            default:
                printf("Opção inválida!\n");
        }
    } while (opcao != 6);

    return 0;
}
