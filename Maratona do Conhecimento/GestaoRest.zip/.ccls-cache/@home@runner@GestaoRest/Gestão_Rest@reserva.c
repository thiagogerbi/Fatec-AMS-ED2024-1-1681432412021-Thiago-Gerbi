#include "reserva.h"

int lugares_ocupados_por_dia[NUM_DIAS] = {0};

No *criarNo(Reserva reserva) {
    No *novo = (No *)malloc(sizeof(No));
    if (novo == NULL) {
        printf("Erro ao alocar memória!\n");
        exit(1);
    }
    novo->reserva = reserva;
    novo->prox = NULL;
    return novo;
}

void adicionarReserva(No **lista, Reserva reserva) {
    int dia = atoi(reserva.data);// Suponha que o dia esteja no início da string

    if (lugares_ocupados_por_dia[dia] + reserva.num_pessoas > MAX_PESSOAS) {
        printf("Capacidade máxima de ocupação para o dia %s atingida. Não é possível adicionar mais reservas.\n", reserva.data);
        return;
    }
    if (reserva.num_pessoas > MAX_PESSOAS) {
        printf("Número de pessoas excede a capacidade máxima permitida.\n");
        return;
    }
    No *novo = criarNo(reserva);
    if (*lista == NULL) {
        *lista = novo;
    } else {
        No *atual = *lista;
        while (atual->prox != NULL) {
            atual = atual->prox;
        }
        atual->prox = novo;
    }
    lugares_ocupados_por_dia[dia] += reserva.num_pessoas;
}

void removerReserva(No **lista, char nome[], char sobrenome[]) {
    No *atual = *lista;
    No *anterior = NULL;
    while (atual != NULL) {
        if (strcmp(atual->reserva.nome, nome) == 0 && strcmp(atual->reserva.sobrenome, sobrenome) == 0) {
            int dia = atoi(atual->reserva.data); // Suponha que o dia esteja no início da string

            lugares_ocupados_por_dia[dia] -= atual->reserva.num_pessoas;
            if (anterior == NULL) {
                *lista = atual->prox;
            } else {
                anterior->prox = atual->prox;
            }
            free(atual);
            printf("Reserva de %s %s removida com sucesso!\n", nome, sobrenome);
            return;
        }
        anterior = atual;
        atual = atual->prox;
    }
    printf("Reserva de %s %s não encontrada!\n", nome, sobrenome);
}

void exibirReservas(No *lista) {
    printf("Lista de Reservas:\n");
    No *atual = lista;
    while (atual != NULL) {
        printf("Nome: %s %s, Num. de Pessoas: %d, Data: %s, Horário: %s\n",
               atual->reserva.nome, atual->reserva.sobrenome, atual->reserva.num_pessoas,
               atual->reserva.data, atual->reserva.horario);
        atual = atual->prox;
    }
}

void consultarReservas(No *lista, char data[], char horario[]) {
    printf("\nReservas para %s às %s:\n", data, horario);
    No *atual = lista;
    int encontradas = 0;
    while (atual != NULL) {
        if (strcmp(atual->reserva.data, data) == 0 &&
            strcmp(atual->reserva.horario, horario) == 0) {
            printf("Nome: %s %s, Num. de Pessoas: %d\n", atual->reserva.nome,
                   atual->reserva.sobrenome, atual->reserva.num_pessoas);
            encontradas = 1;
        }
        atual = atual->prox;
    }
    if (!encontradas) {
        printf("Nenhuma reserva encontrada para este horário.\n");
    }
}

void relatorioOcupacao(No *lista, char inicio_data[], char fim_data[]) {
    printf("\nRelatório de Ocupação do Restaurante:\n");
    No *atual = lista;
    int total_lugares_ocupados = 0;
    while (atual != NULL) {
        if (strcmp(atual->reserva.data, inicio_data) >= 0 &&
            strcmp(atual->reserva.data, fim_data) <= 0) {
            total_lugares_ocupados += atual->reserva.num_pessoas;
        }
        atual = atual->prox;
    }
    printf("Total de lugares ocupados: %d\n", total_lugares_ocupados);
}

int validarData(char data[]) {
    if (strlen(data) != 10)
        return 0;
    for (int i = 0; i < 10; i++) {
        if (i == 2 || i == 5) {
            if (data[i] != '-')
                return 0;
        } else {
            if (!isdigit(data[i]))
                return 0;
        }
    }
    return 1;
}

int validarHorario(char horario[]) {
    if (strlen(horario) != 5)
        return 0;
    if (horario[2] != ':')
        return 0;
    for (int i = 0; i < 5; i++) {
        if (i != 2) {
            if (!isdigit(horario[i]))
                return 0;
        }
    }
    return 1;
}
